package com.leonardomoreira.pokedex.pokeapi;

import android.os.Bundle;
import android.content.Intent;
import android.os.Handler;

import com.leonardomoreira.pokedex.MainActivity;
import com.leonardomoreira.pokedex.R;

public class Activity_Splash_Screen extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__splash__screen);
        Handler handle = new Handler();
        handle.postDelayed(new Runnable() {
            @Override
            public void run() {
                showMainActivity();
            }
        }, 3000);
    }
    

    private void showMainActivity() {
        Intent intent = new Intent(Activity_Splash_Screen.this,MainActivity.class);
        startActivity(intent);
        finish();
    }
}
