package com.leonardomoreira.pokedex.pokeapi;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
import com.leonardomoreira.pokedex.models.PokemonTime;

public interface PokeapiService {

    @GET("pokemon")
    Call<PokemonTime> obtenerListaPokemon(@Query("limit") int limit, @Query("offset") int offset);

}
