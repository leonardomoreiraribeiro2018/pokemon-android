package com.leonardomoreira.pokedex;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import com.leonardomoreira.pokedex.models.Pokemon;
import com.leonardomoreira.pokedex.models.PokemonTime;
import com.leonardomoreira.pokedex.pokeapi.PokeapiService;
import com.leonardomoreira.pokedex.pokeapi.RecyclerTouchListener;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "POKEDEX";

    private Retrofit retrofit;
    private RecyclerView recyclerView;
    private ListPokemonAdapter listPokemonAdapter;
    private int offset;

    private boolean availableUpdate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.leonardomoreira.pokedex.R.layout.activity_main);


        recyclerView = (RecyclerView) findViewById(com.leonardomoreira.pokedex.R.id.recyclerView);
        listPokemonAdapter = new ListPokemonAdapter(this);
        recyclerView.setAdapter(listPokemonAdapter);
        recyclerView.setHasFixedSize(true);
        final GridLayoutManager layoutManager = new GridLayoutManager(this, 3);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                if (dy > 0) {
                    int visibleItemCount = layoutManager.getChildCount();
                    int totalItemCount = layoutManager.getItemCount();
                    int pastVisibleItems = layoutManager.findFirstVisibleItemPosition();

                    if (availableUpdate) {
                        if ((visibleItemCount + pastVisibleItems) >= totalItemCount) {

                            availableUpdate = false;
                            offset +=20;
                            obtenerDatos(offset);
                        }
                    }
                }
            }
        });


        retrofit = new Retrofit.Builder()
                .baseUrl("http://pokeapi.co/api/v2/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        availableUpdate = true;
        offset = 0;
        obtenerDatos(offset);
    }

    private void obtenerDatos(int offset) {
        PokeapiService service = retrofit.create(PokeapiService.class);
        Call<PokemonTime> pokemonTimeCall = service.obtenerListaPokemon(20, offset);

        pokemonTimeCall.enqueue(new Callback<PokemonTime>() {
            @Override
            public void onResponse(Call<PokemonTime> call, Response<PokemonTime> response) {
                availableUpdate = true;
                if (response.isSuccessful()) {

                    PokemonTime pokemonTime = response.body();
                    ArrayList<Pokemon> listPokemon = pokemonTime.getResults();

                    listPokemonAdapter.adicionarListaPokemon(listPokemon);

                } else {
                    Log.e(TAG, " onResponse: " + response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<PokemonTime> call, Throwable t) {
                availableUpdate = true;
                Log.e(TAG, " onFailure: " + t.getMessage());
            }
        });
    }
}
